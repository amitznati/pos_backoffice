@extends('backpack::layout')

@section('after_scripts')
    @include('products.department_change_script')
@endsection


<?php 

 return [
    "previous" => "« Previous",
    "next" => "Next »"
];
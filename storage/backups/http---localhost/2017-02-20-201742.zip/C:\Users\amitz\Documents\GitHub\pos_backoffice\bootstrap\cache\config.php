<?php return array (
  'app' => 
  array (
    'name' => 'Laravel',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost',
    'timezone' => 'UTC',
    'locale' => 'en',
    'languages' => 
    array (
      0 => 'he',
      1 => 'en',
    ),
    'fallback_locale' => 'en',
    'key' => 'base64:0ND7v6cmfjzCd3atn33rBeynTO2mN1psPwgZYImINWY=',
    'cipher' => 'AES-256-CBC',
    'log' => 'single',
    'log_level' => 'debug',
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'Backpack\\Base\\BaseServiceProvider',
      23 => 'Backpack\\CRUD\\CrudServiceProvider',
      24 => 'Backpack\\LangFileManager\\LangFileManagerServiceProvider',
      25 => 'Spatie\\Backup\\BackupServiceProvider',
      26 => 'Backpack\\BackupManager\\BackupManagerServiceProvider',
      27 => 'Backpack\\LogManager\\LogManagerServiceProvider',
      28 => 'Backpack\\Settings\\SettingsServiceProvider',
      29 => 'Cviebrock\\EloquentSluggable\\ServiceProvider',
      30 => 'Backpack\\PageManager\\PageManagerServiceProvider',
      31 => 'Backpack\\PermissionManager\\PermissionManagerServiceProvider',
      32 => 'App\\Providers\\AppServiceProvider',
      33 => 'App\\Providers\\AuthServiceProvider',
      34 => 'App\\Providers\\EventServiceProvider',
      35 => 'App\\Providers\\RouteServiceProvider',
      36 => 'Collective\\Html\\HtmlServiceProvider',
      37 => 'Laracasts\\Flash\\FlashServiceProvider',
      38 => 'Prettus\\Repository\\Providers\\RepositoryServiceProvider',
      39 => 'InfyOm\\Generator\\InfyOmGeneratorServiceProvider',
      40 => 'InfyOm\\AdminLTETemplates\\AdminLTETemplatesServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Redis' => 'Illuminate\\Support\\Facades\\Redis',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Form' => 'Collective\\Html\\FormFacade',
      'Html' => 'Collective\\Html\\HtmlFacade',
      'Flash' => 'Laracasts\\Flash\\Flash',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'api' => 
      array (
        'driver' => 'token',
        'provider' => 'users',
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_resets',
        'expire' => 60,
      ),
    ),
  ),
  'backpack' => 
  array (
    'base' => 
    array (
      'project_name' => 'Backpack',
      'logo_lg' => '<b>my</b>Pos',
      'logo_mini' => '<b>m</b>P',
      'developer_name' => 'Amit Znati',
      'developer_link' => 'http://amitznati.ro',
      'show_powered_by' => true,
      'skin' => 'skin-blue',
      'default_date_format' => 'j F Y',
      'default_datetime_format' => 'j F Y H:i',
      'registration_open' => true,
      'route_prefix' => 'admin',
      'setup_auth_routes' => true,
      'setup_dashboard_routes' => true,
      'user_model_fqn' => '\\App\\User',
    ),
    'crud' => 
    array (
      'default_save_action' => 'save_and_back',
      'tabs_type' => 'horizontal',
      'show_grouped_errors' => true,
      'show_inline_errors' => true,
      'default_page_length' => 25,
      'show_translatable_field_icon' => true,
      'translatable_field_icon_position' => 'right',
      'locales' => 
      array (
        'en' => 'English',
        'fr' => 'French',
        'it' => 'Italian',
        'ro' => 'Romanian',
      ),
    ),
    'langfilemanager' => 
    array (
      'language_ignore' => 
      array (
        0 => 'reminders',
        1 => 'log',
        2 => 'crud',
      ),
    ),
    'permissionmanager' => 
    array (
      'user_model' => 'App\\User',
      'allow_permission_create' => true,
      'allow_permission_update' => true,
      'allow_permission_delete' => true,
      'allow_role_create' => true,
      'allow_role_update' => true,
      'allow_role_delete' => true,
    ),
    'backupmanager' => 
    array (
      'backup' => 
      array (
        'name' => 'http://localhost',
        'source' => 
        array (
          'files' => 
          array (
            'include' => 
            array (
              0 => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice',
            ),
            'exclude' => 
            array (
              0 => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\vendor',
              1 => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\storage',
            ),
          ),
          'databases' => 
          array (
            0 => 'mysql',
          ),
        ),
        'destination' => 
        array (
          'disks' => 
          array (
            0 => 'backups',
          ),
        ),
      ),
      'cleanup' => 
      array (
        'strategy' => 'Spatie\\Backup\\Tasks\\Cleanup\\Strategies\\DefaultStrategy',
        'defaultStrategy' => 
        array (
          'keepAllBackupsForDays' => 7,
          'keepDailyBackupsForDays' => 16,
          'keepWeeklyBackupsForWeeks' => 8,
          'keepMonthlyBackupsForMonths' => 4,
          'keepYearlyBackupsForYears' => 2,
          'deleteOldestBackupsWhenUsingMoreMegabytesThan' => 5000,
        ),
      ),
      'monitorBackups' => 
      array (
        0 => 
        array (
          'name' => 'http://localhost',
          'disks' => 
          array (
            0 => 'backups',
          ),
          'newestBackupsShouldNotBeOlderThanDays' => 1,
          'storageUsedMayNotBeHigherThanMegabytes' => 5000,
        ),
      ),
      'notifications' => 
      array (
        'handler' => 'Spatie\\Backup\\Notifications\\Notifier',
        'events' => 
        array (
          'whenBackupWasSuccessful' => 
          array (
            0 => 'log',
          ),
          'whenCleanupWasSuccessful' => 
          array (
            0 => 'log',
          ),
          'whenHealthyBackupWasFound' => 
          array (
            0 => 'log',
          ),
          'whenBackupHasFailed' => 
          array (
            0 => 'log',
            1 => 'mail',
          ),
          'whenCleanupHasFailed' => 
          array (
            0 => 'log',
            1 => 'mail',
          ),
          'whenUnHealthyBackupWasFound' => 
          array (
            0 => 'log',
            1 => 'mail',
          ),
        ),
        'mail' => 
        array (
          'from' => 'your@email.com',
          'to' => 'your@email.com',
        ),
        'slack' => 
        array (
          'channel' => '#backups',
          'username' => 'Backup bot',
          'icon' => ':robot:',
        ),
      ),
    ),
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '',
        'secret' => '',
        'app_id' => '',
        'options' => 
        array (
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\storage\\framework/cache',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
    ),
    'prefix' => 'laravel',
  ),
  'compile' => 
  array (
    'files' => 
    array (
    ),
    'providers' => 
    array (
    ),
  ),
  'database' => 
  array (
    'fetch' => 5,
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'database' => 'pos6',
        'prefix' => '',
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'pos6',
        'username' => 'amitznati',
        'password' => 'Gnh,zbyh',
        'charset' => 'utf8',
        'collation' => 'utf8_unicode_ci',
        'prefix' => '',
        'strict' => true,
        'engine' => NULL,
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'pos6',
        'username' => 'amitznati',
        'password' => 'Gnh,zbyh',
        'charset' => 'utf8',
        'prefix' => '',
        'schema' => 'public',
        'sslmode' => 'prefer',
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'cluster' => false,
      'default' => 
      array (
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => 0,
      ),
    ),
  ),
  'elfinder' => 
  array (
    'dir' => 
    array (
      0 => 'uploads',
    ),
    'disks' => 
    array (
    ),
    'route' => 
    array (
      'prefix' => 'admin/elfinder',
      'middleware' => 
      array (
        0 => 'web',
        1 => 'auth',
      ),
    ),
    'access' => 'Barryvdh\\Elfinder\\Elfinder::checkAccess',
    'roots' => NULL,
    'options' => 
    array (
    ),
    'root_options' => 
    array (
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'cloud' => 's3',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\storage\\app',
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\storage\\app/public',
        'visibility' => 'public',
      ),
      'uploads' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\public\\uploads',
      ),
      'backups' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\storage\\backups',
      ),
      'storage' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\storage',
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => 'your-key',
        'secret' => 'your-secret',
        'region' => 'your-region',
        'bucket' => 'your-bucket',
      ),
    ),
  ),
  'image' => 
  array (
    'driver' => 'gd',
  ),
  'infyom' => 
  array (
    'laravel_generator' => 
    array (
      'path' => 
      array (
        'migration' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\database/migrations/',
        'model' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\app\\Models/',
        'datatables' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\app\\DataTables/',
        'repository' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\app\\Repositories/',
        'routes' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\routes/web.php',
        'api_routes' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\routes/api.php',
        'request' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\app\\Http/Requests/',
        'api_request' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\app\\Http/Requests/API/',
        'controller' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\app\\Http/Controllers/',
        'api_controller' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\app\\Http/Controllers/API/',
        'test_trait' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\tests/traits/',
        'repository_test' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\tests/',
        'api_test' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\tests/',
        'views' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\resources/views/',
        'schema_files' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\resources/model_schemas/',
        'templates_dir' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\resources/infyom/infyom-generator-templates/',
        'modelJs' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\resources/assets/js/models/',
      ),
      'namespace' => 
      array (
        'model' => 'App\\Models',
        'datatables' => 'App\\DataTables',
        'repository' => 'App\\Repositories',
        'controller' => 'App\\Http\\Controllers',
        'api_controller' => 'App\\Http\\Controllers\\API',
        'request' => 'App\\Http\\Requests',
        'api_request' => 'App\\Http\\Requests\\API',
      ),
      'templates' => 'adminlte-templates',
      'model_extend_class' => 'Eloquent',
      'api_prefix' => 'api',
      'api_version' => 'v1',
      'options' => 
      array (
        'softDelete' => true,
        'tables_searchable_default' => false,
      ),
      'prefixes' => 
      array (
        'route' => '',
        'path' => '',
        'view' => '',
        'public' => '',
      ),
      'add_on' => 
      array (
        'swagger' => false,
        'tests' => true,
        'datatables' => false,
        'menu' => 
        array (
          'enabled' => true,
          'menu_file' => 'layouts/menu.blade.php',
        ),
      ),
      'timestamps' => 
      array (
        'enabled' => true,
        'created_at' => 'created_at',
        'updated_at' => 'updated_at',
        'deleted_at' => 'deleted_at',
      ),
    ),
  ),
  'laravel-backup' => 
  array (
    'backup' => 
    array (
      'name' => 'http://localhost',
      'source' => 
      array (
        'files' => 
        array (
          'include' => 
          array (
            0 => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice',
          ),
          'exclude' => 
          array (
            0 => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\vendor',
            1 => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\storage',
          ),
        ),
        'databases' => 
        array (
          0 => 'mysql',
        ),
      ),
      'destination' => 
      array (
        'disks' => 
        array (
          0 => 'backups',
        ),
      ),
    ),
    'cleanup' => 
    array (
      'strategy' => 'Spatie\\Backup\\Tasks\\Cleanup\\Strategies\\DefaultStrategy',
      'defaultStrategy' => 
      array (
        'keepAllBackupsForDays' => 7,
        'keepDailyBackupsForDays' => 16,
        'keepWeeklyBackupsForWeeks' => 8,
        'keepMonthlyBackupsForMonths' => 4,
        'keepYearlyBackupsForYears' => 2,
        'deleteOldestBackupsWhenUsingMoreMegabytesThan' => 5000,
      ),
    ),
    'monitorBackups' => 
    array (
      0 => 
      array (
        'name' => 'http://localhost',
        'disks' => 
        array (
          0 => 'backups',
        ),
        'newestBackupsShouldNotBeOlderThanDays' => 1,
        'storageUsedMayNotBeHigherThanMegabytes' => 5000,
      ),
    ),
    'notifications' => 
    array (
      'handler' => 'Spatie\\Backup\\Notifications\\Notifier',
      'events' => 
      array (
        'whenBackupWasSuccessful' => 
        array (
          0 => 'log',
        ),
        'whenCleanupWasSuccessful' => 
        array (
          0 => 'log',
        ),
        'whenHealthyBackupWasFound' => 
        array (
          0 => 'log',
        ),
        'whenBackupHasFailed' => 
        array (
          0 => 'log',
          1 => 'mail',
        ),
        'whenCleanupHasFailed' => 
        array (
          0 => 'log',
          1 => 'mail',
        ),
        'whenUnHealthyBackupWasFound' => 
        array (
          0 => 'log',
          1 => 'mail',
        ),
      ),
      'mail' => 
      array (
        'from' => 'your@email.com',
        'to' => 'your@email.com',
      ),
      'slack' => 
      array (
        'channel' => '#backups',
        'username' => 'Backup bot',
        'icon' => ':robot:',
      ),
    ),
  ),
  'laravel-permission' => 
  array (
    'models' => 
    array (
      'permission' => 'Backpack\\PermissionManager\\app\\Models\\Permission',
      'role' => 'Backpack\\PermissionManager\\app\\Models\\Role',
    ),
    'table_names' => 
    array (
      'users' => 'users',
      'roles' => 'roles',
      'permissions' => 'permissions',
      'user_has_permissions' => 'permission_users',
      'user_has_roles' => 'role_users',
      'role_has_permissions' => 'permission_roles',
    ),
  ),
  'mail' => 
  array (
    'driver' => 'smtp',
    'host' => 'mailtrap.io',
    'port' => '2525',
    'from' => 
    array (
      'address' => 'hello@example.com',
      'name' => 'Example',
    ),
    'encryption' => NULL,
    'username' => NULL,
    'password' => NULL,
    'sendmail' => '/usr/sbin/sendmail -bs',
  ),
  'prologue' => 
  array (
    'alerts' => 
    array (
      'levels' => 
      array (
        0 => 'info',
        1 => 'warning',
        2 => 'error',
        3 => 'success',
      ),
      'session_key' => 'alert_messages',
    ),
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => 'your-public-key',
        'secret' => 'your-secret-key',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'your-queue-name',
        'region' => 'us-east-1',
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
      ),
    ),
    'failed' => 
    array (
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'repository' => 
  array (
    'pagination' => 
    array (
      'limit' => 15,
    ),
    'fractal' => 
    array (
      'params' => 
      array (
        'include' => 'include',
      ),
      'serializer' => 'League\\Fractal\\Serializer\\DataArraySerializer',
    ),
    'cache' => 
    array (
      'enabled' => true,
      'minutes' => 30,
      'repository' => 'cache',
      'clean' => 
      array (
        'enabled' => true,
        'on' => 
        array (
          'create' => true,
          'update' => true,
          'delete' => true,
        ),
      ),
      'params' => 
      array (
        'skipCache' => 'skipCache',
      ),
      'allowed' => 
      array (
        'only' => NULL,
        'except' => NULL,
      ),
    ),
    'criteria' => 
    array (
      'acceptedConditions' => 
      array (
        0 => '=',
        1 => 'like',
      ),
      'params' => 
      array (
        'search' => 'search',
        'searchFields' => 'searchFields',
        'filter' => 'filter',
        'orderBy' => 'orderBy',
        'sortedBy' => 'sortedBy',
        'with' => 'with',
      ),
    ),
    'generator' => 
    array (
      'basePath' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\app',
      'rootNamespace' => 'App\\',
      'paths' => 
      array (
        'models' => 'Entities',
        'repositories' => 'Repositories',
        'interfaces' => 'Repositories',
        'transformers' => 'Transformers',
        'presenters' => 'Presenters',
        'validators' => 'Validators',
        'controllers' => 'Http/Controllers',
        'provider' => 'RepositoryServiceProvider',
        'criteria' => 'Criteria',
        'stubsOverridePath' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\app',
      ),
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
    ),
    'ses' => 
    array (
      'key' => NULL,
      'secret' => NULL,
      'region' => 'us-east-1',
    ),
    'sparkpost' => 
    array (
      'secret' => NULL,
    ),
    'stripe' => 
    array (
      'model' => 'App\\User',
      'key' => NULL,
      'secret' => NULL,
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => 120,
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\storage\\framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'laravel_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => false,
    'http_only' => true,
  ),
  'sluggable' => 
  array (
    'source' => NULL,
    'maxLength' => NULL,
    'method' => NULL,
    'separator' => '-',
    'unique' => true,
    'uniqueSuffix' => NULL,
    'includeTrashed' => false,
    'reserved' => NULL,
    'onUpdate' => false,
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\resources\\views',
    ),
    'compiled' => 'C:\\Users\\amitz\\Documents\\GitHub\\pos_backoffice\\storage\\framework\\views',
  ),
  0 => 'config/laravel-backup.php',
  'langfilemanager' => 
  array (
    'language_ignore' => 
    array (
      0 => 'pagination',
      1 => 'reminders',
      2 => 'validation',
      3 => 'log',
      4 => 'crud',
    ),
  ),
);
